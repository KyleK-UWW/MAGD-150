let ballPosition = [];
let num = 10;
let x;
let y;
let yDirect;
let xDirect;

function setup() {
createCanvas(400, 400);
 x = random(1,399);
 y = random(1,399);
 yDirect = 1;
 xDirect = 1;

for(let i=0; i<num; i++){
ballPosition[i] = [];
for (let p=0; p<2; p++){
ballPosition[i][p] = -100;
}
}
console.log(ballPosition);
}
function draw() {
background(0);
stroke("cyan")
strokeWeight(20);
line(0,325,325,0);
line(0,375,375,0);
noStroke();
fill("purple");
triangle(180,25,25,240,340,240);
fill("green");

noStroke();
ballPosition[ballPosition.length-1][0] = mouseX;
ballPosition[ballPosition.length-1][1] = mouseY;
for(let r=0;r<ballPosition.length-1;r++){
for(let s = 0; s<2; s++){
ballPosition[r][s] = ballPosition[r+1][s];
}
}
for(let i=0; i<num; i++){
//fill((i+1)*25);
circle(ballPosition[i][0],ballPosition[i][1],30);
}
fill("yellow");
	square(x,y,50);

	if(x > 355 ){

	xDirect = -1;
}

	else if(x < 1){

   	xDirect = 1;

}

	if(xDirect == 1){
	
      x+=5;
}

	else if(xDirect == -1){
	
      x-=5;
}
  if(y > 355 ){

	yDirect = -1;
}

	else if(y < 1){

   	yDirect = 1;

}

	if(yDirect == 1){
	
      y+=5;
}

	else if(yDirect == -1){
	
      y-=5;
}

}