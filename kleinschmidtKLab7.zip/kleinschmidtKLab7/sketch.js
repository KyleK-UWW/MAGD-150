
let colors = ['red','blue','yellow','green','orange','cyan','purple','grey'];
let array1 = [];
let arrayX = [];
let arrayY = [];
let coordinates = [];

function setup() {
   createCanvas(400, 400);
   background(220)
for (let p = 0; p<5; p++){
    let num = Math.floor(random(0,colors.length));
    console.log(num);
    array1.push(colors[num]);
    colors.splice(num,1);
    arrayX.push(Math.floor(random(10,width-50)));
    arrayY.push(Math.floor(random(10,height-50)));
}
    console.log(arrayX);
    console.log(arrayY);
  coordinates = arrayX.concat(arrayY);
  text("ArrayX: " + arrayX,80,80);
  text("ArrayY: " + arrayY,60,60);
  text("Random1: " + arrayX[Math.floor(random(0,arrayX.length))],100,100);
  text("Random2: " + arrayY[Math.floor(random(0,arrayY.length))],150,150);
  text("Random1&2: " + coordinates[Math.floor(random(0,coordinates.length))],200,200);
  text("The remaining colors are: "+colors,50,360);
    
  }

   


function draw() {
}
