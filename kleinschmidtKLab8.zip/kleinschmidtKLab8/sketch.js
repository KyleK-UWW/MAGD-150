
// background.png from Pixabay.com
// snowman.png from Pixabay.com


let bgImg;
let snowmanImg;

function preload() {
  bgImg = loadImage('assets/Christmas.png'); 
  snowmanImg = loadImage('assets/Snowman.png');
}

function setup() {
   createCanvas(400, 400);
  textFont('Helvetica'); 
  textAlign(CENTER, CENTER);
}

function draw() {
  background(220);

   image(bgImg, 0, 0, width, height);

   push();  
 translate(mouseX, 300);  
let s = map(mouseY, 0, height, 0.5, 1.5);   scale(s);
  imageMode(CENTER);
  image(snowmanImg, 0, 0, 150, 150);
  pop();

  // Text setup
  stroke(0);
  strokeWeight(2);
  fill(255, 0, 0);
  textSize(24);

  
  text("Happy Holidays!", width / 2, 50, 100, 100);
}